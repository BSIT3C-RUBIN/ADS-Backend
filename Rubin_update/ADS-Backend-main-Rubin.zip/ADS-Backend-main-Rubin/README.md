# Backend namin to pang malakas to
