CREATE DATABASE animal_shelter

