USE animal_shelter;
INSERT INTO animal_med_history (vacc_type, vacc_date, vacc_dose, animal_id) VALUES
('Rabies', '2024-01-15', 1, 1),
('Parvovirus', '2024-02-10', 1, 1),
('Feline Leukemia', '2024-03-05', 1, 2),
('Distemper', '2024-04-01', 1, 2),
('Rabies', '2024-01-20', 1, 3),
('Bordetella', '2024-03-15', 1, 3),
('Canine Influenza', '2024-02-25', 1, 4),
('Parvo', '2024-04-10', 2, 4);

